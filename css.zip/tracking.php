<?php
        include('./track_page_visits.php');
        display_visited_pages();
?>