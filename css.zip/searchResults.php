<?php

echo "Got - ".$_GET['search'];

?>